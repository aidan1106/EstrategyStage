USE [4food.aidan];
GO

IF OBJECT_ID('dbo.Napoleon_All', 'U') IS NOT NULL
    DROP TABLE dbo.Napoleon_All;

CREATE TABLE dbo.Napoleon_All
(
    Jaar              INT,
    Maand             INT,
    Artikelnummer     NVARCHAR(50),
    GroepNaam         NVARCHAR(255),
    TotaalQuantity    DECIMAL(18,3),
    PrognoseWaarde    DECIMAL(18,3)
);

;WITH YearMonthCount AS
(
    SELECT 
        YEAR(deliveryDate) AS Jaar,
        COUNT(DISTINCT MONTH(deliveryDate)) AS MonthsWithData
    FROM [4food.napoleon.productie].[dbo].[orderinfo]
    GROUP BY YEAR(deliveryDate)
    HAVING COUNT(DISTINCT MONTH(deliveryDate)) >= 10
),
Quantiles AS
(
    SELECT
        PERCENTILE_CONT(0.01) WITHIN GROUP (ORDER BY opb.quantity) OVER () AS Q1_quantity,
        PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY opb.quantity) OVER () AS Q99_quantity
    FROM [4food.napoleon.productie].[dbo].[opb] opb
),
Data_CTE AS
(
    SELECT
        YEAR(oi.deliveryDate)  AS Jaar,
        MONTH(oi.deliveryDate) AS Maand,
        opb.artikelnummer      AS Artikelnummer,
        g.groepnaam            AS GroepNaam,
        CASE 
            WHEN oi.orderType = 18 AND opb.quantity > 0 THEN -opb.quantity
            ELSE opb.quantity
        END                    AS Quantity
    FROM [4food.napoleon.productie].[dbo].[orderinfo] oi
    INNER JOIN [4food.napoleon.productie].[dbo].[opb] opb
        ON oi.id = opb.orderInfoId
    INNER JOIN YearMonthCount ym
        ON ym.Jaar = YEAR(oi.deliveryDate)
    CROSS JOIN (SELECT DISTINCT Q1_quantity, Q99_quantity FROM Quantiles) q

    LEFT JOIN [4food.napoleon.productie].[dbo].[specificaties] s
        ON s.id = opb.artikelnummer
    LEFT JOIN [4food.napoleon.productie].[dbo].[specificationProductGroup] spg
        ON spg.specificationId = s.internalId
    LEFT JOIN [4food.napoleon.productie].[dbo].[groepen] g
        ON g.id = spg.groupID

    WHERE oi.orderStatus <> 4
      AND oi.orderType IN (2,3,4,18)
      AND opb.quantity   <> 0
      AND opb.priceKG > 0.001
      AND (opb.quantity < 0 OR (opb.quantity BETWEEN q.Q1_quantity AND q.Q99_quantity))
),
Jaarschema_CTE AS
(
    SELECT 
        j.jaar,
        j.maand,
        j.artikel,
        g.groepnaam,
        SUM(j.aantalhe) AS PrognoseWaarde
    FROM [4food.napoleon.productie].[dbo].[jaarschema] j
    INNER JOIN YearMonthCount ym
        ON ym.Jaar = j.jaar

    LEFT JOIN [4food.napoleon.productie].[dbo].[specificaties] s
        ON s.id = j.artikel
    LEFT JOIN [4food.napoleon.productie].[dbo].[specificationProductGroup] spg
        ON spg.specificationId = s.internalId
    LEFT JOIN [4food.napoleon.productie].[dbo].[groepen] g
        ON g.id = spg.groupID

    GROUP BY j.jaar, j.maand, j.artikel, g.groepnaam
)
INSERT INTO dbo.Napoleon_All
(
    Jaar, 
    Maand, 
    Artikelnummer, 
    GroepNaam,
    TotaalQuantity, 
    PrognoseWaarde
)
SELECT
    COALESCE(d.Jaar, j.jaar)               AS Jaar,
    COALESCE(d.Maand, j.maand)             AS Maand,
    COALESCE(d.Artikelnummer, j.artikel)   AS Artikelnummer,         
    COALESCE(d.GroepNaam, j.groepnaam, '-') AS GroepNaam,       
    SUM(ISNULL(d.Quantity, 0))             AS TotaalQuantity,
    SUM(ISNULL(j.PrognoseWaarde, 0))       AS PrognoseWaarde
FROM Data_CTE d
FULL OUTER JOIN Jaarschema_CTE j
    ON d.Jaar = j.jaar
    AND d.Maand = j.maand
    AND d.Artikelnummer = j.artikel
GROUP BY
    COALESCE(d.Jaar, j.jaar),
    COALESCE(d.Maand, j.maand),
    COALESCE(d.Artikelnummer, j.artikel),
    COALESCE(d.GroepNaam, j.groepnaam, '-')
ORDER BY
    Jaar, Maand, Artikelnummer;
